import React from 'react'

function Procedure() {
  return (
    <div>
      
    </div>
  )
}

export default Procedure
