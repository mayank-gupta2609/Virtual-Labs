import React from 'react'
import ContentPage from './ContentPage'
import Navbar from './Navbar'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import MainPage from './MainPage';
import ExpDetails from './ExpDetails';
import Theory from './Theory';

function Home() {
    return (
        <>
            <Navbar /> 
            <div style={{ 
                backgroundColor:'#181818',
                height:'100vh',
                overflowY: 'scroll',
                overflowX: 'hidden',
                paddingBottom: '50px',
            }}>

            <Routes >
                <Route exact path='/' element={<MainPage/>} />
                <Route exact path='/@PhysicalChemistry' element={<ContentPage/>} />
                <Route exact path='/@OrganicChemistry' element={<ContentPage/>} />
                <Route exact path='/@InorganicChemistry' element={<ContentPage/>} /> 
                <Route exact path='/experiments/:title' element={<ExpDetails />} /> 
            </Routes>
            </div>
        </>
    )
}

export default Home
