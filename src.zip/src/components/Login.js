import { signInWithPopup } from "firebase/auth";
import { auth, provider } from "../firebase";
import styled from "styled-components";
import LoadingBar from 'react-top-loading-bar'
import { useState } from "react";

function Login() {

    const [color, setColor] = useState("red")
    const [progress, setProgress] = useState(0)

    const signIn = () => {
        setProgress(0)
        setColor("orange")
        signInWithPopup(auth, provider).catch(alert)
        setProgress(100)
        setColor("red")
    }

    return (
        <>
            <LoadingBar
                color={color}
                progress={progress}
                onLoaderFinished={() => setProgress(0)}
            />
            <div style={{ height: '100vh', width: '100vw', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: 'black' }}>
                <Button onClick={signIn}  >
                    Sign In
                </Button>
            </div>
        </>
    )
}

export default Login;


const Button = styled.div`
    background-color:orange;
    height:70px;
    width:150px;
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius:4px;
    font-family: Roboto, Noto Naskh Arabic UI, Arial, sans-serif;
    font-size:35px;

    :hover {
        opacity: 0.7
    }
`;