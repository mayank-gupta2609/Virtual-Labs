import React, { useEffect } from 'react'
import { Link } from "react-router-dom";
import { useState } from 'react'; 
import { useDispatch, useSelector } from 'react-redux';
import { setSection } from '../redux/features/userSlice';
import { signOut } from "firebase/auth";
import { db, auth } from '../firebase';
import { useAuthState } from 'react-firebase-hooks/auth';

const Navbar = () => { 
    
    const dispatch = useDispatch();
    const [user] = useAuthState(auth);

    const [cityName, setCityName] = useState("");
    const [temperature, setTemp] = useState("");

    let today = new Date().toISOString().slice(0, 10)
    const apiKey = "b12e7d516eadb4a44aba891f5a843f45";
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=23.0225&lon=72.5714&appid=${apiKey}&units=metric`;
    let parsedData;


    const getWeather = async () => {
        let data = await fetch(url); 
        parsedData = await data.json() 
        setCityName(parsedData.name);
        setTemp(parsedData.main.temp);
    }

    useEffect(()=>{
        getWeather(); 
    }, [])

    return (
        <div >
            <nav className="navbar fixed-top navbar-expand-lg navbar-dark bg-dark d-flex ">
                <div className="container-fluid">
                    <Link className="navbar-brand" to="/">Virtual Labs</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <Link className="nav-link" aria-current="page" to="/@PhysicalChemistry" onClick={()=> {
                                    dispatch(setSection("Physical Chemistry"))
                                }}
                                >Physical Chemistry</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/@OrganicChemistry" onClick={()=> {
                                    dispatch(setSection("Organic Chemistry"))
                                }}>Organic Chemistry</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/@InOrganicChemistry" onClick={()=> {
                                    dispatch(setSection("InOrganic Chemistry"))
                                }}>InOrganic Chemistry</Link>
                            </li> 
                            
                        </ul>
                    </div>

                </div>

                <div className="container-fluid justify-content-end">
                    <ul className="navbar-nav   mb-2 mb-lg-0 ">
                        <li className="nav-item d-flex" style={{ color: 'white' }}> 
                        <li className="d-flex ">

                            <div style={{paddingRight:'15px', paddingTop:'6px'}}>  {today}</div>
                            <div>

                            {user?.displayName}
                            <img src={user?.photoURL} alt="" style={{
                                height:'40px',
                                borderRadius:'50%' 
                            }} className="ms-3 me-2"/>
                            </div>
                        </li>
                        </li>
                    </ul>

                </div> 

                <div  onClick={()=>signOut(auth)} style={{
                    color:'white',
                    marginRight:'20px',
                }}>
                <i className="fa-solid fa-arrow-right-from-bracket"></i>
                </div>
            </nav>
        </div>

        


    )
}
 

export default Navbar
