import React from 'react'

function PageNotFound() {
  return (
    <div style={{
      marginTop:'100px',
      display:'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }}>
        <h1 style={{color:'white'}}>Page Currently Under Development....Stay Tuned</h1>
    </div>
  )
}

export default PageNotFound
