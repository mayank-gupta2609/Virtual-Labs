import React from 'react'

function Theory() {
  return (
    <div>
      
    </div>
  )
}

export default Theory
