import React from 'react'

function Questionarie() {
  return (
    <div>
      
    </div>
  )
}

export default Questionarie
