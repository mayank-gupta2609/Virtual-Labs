import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import LoadingBar from 'react-top-loading-bar'
import { setExpID } from '../redux/features/userSlice'

function MainPage() {

    const dispatch = useDispatch()
    const { experimentId, section } = useSelector((state) => state.user)
    const navigate = useNavigate()
    const [experiments, setExperiments] = useState()
    const [loading, setLoading] = useState(true)
    const [progress, setProgress] = useState(0)
    const [color, setColor] = useState("red")

    const getExperiments = async () => {
        setLoading(true)
        setProgress(0)
        setColor("orange")

        let response = await fetch("http://localhost:5000/api/experiments/getAllExperiments");
        setProgress(50)
        setColor("aqua")

        let data = await response.json();
        console.log(data);
        setColor("pink")
        setProgress(70)

        setExperiments(data)
        setLoading(false)
        setProgress(100)
        setColor("red")
    }

    useEffect(() => {
        getExperiments()
    }, [])

    return (
        <>
            <LoadingBar
                color={color}
                progress={progress}
                onLoaderFinished={() => setProgress(0)}
            />

            <div style={{
                paddingTop: '100px',
                color: 'white',
                width: '100vw',
                alignItems: 'center',
                justifyContent: 'center'

            }}>
                <h1 style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}>Three Core Branches of Chemistry</h1>

                <div className=" d-flex align-items-center justify-content-center mt-4" style={{

                }}>
                    <div className="card ms-3 me-3 bg-dark " style={{ width: "18rem" }}>
                        <img className="card-img-top" src="https://play-lh.googleusercontent.com/h47gskKMUDozoKC2Q4cilvQqjMP8sxGk1pjwD7CyhO6gW64ab9luP0dkp-k-PWjT0A" alt="Card image cap" />
                        <div className="card-body ">
                            <h5 className="card-title">Physical Chemistry</h5>
                            <p className="card-text">Physical chemistry, branch of chemistry concerned with interactions and transformations of materials. Unlike other branches, it deals with the principles of physics underlying all chemical interactions (e.g., gas laws), seeking to measure, correlate, and explain the quantitative aspects of reactions. </p>

                        </div>
                    </div>

                    <div className="card ms-3 me-3 bg-dark " style={{ width: "18rem" }}>
                        <img className="card-img-top" src="https://edurev.gumlet.io/AllImages/original/ApplicationImages/CourseImages/b122cffe-81f8-4bb2-a1f8-fca2567f0fa0_CI.png?w=100&dpr=2.6" alt="Card image cap" />
                        <div className="card-body ">
                            <h5 className="card-title">Organic Chemistry</h5>
                            <p className="card-text">Organic chemistry is the study of the structure, properties, composition, reactions, and preparation of carbon-containing compounds. Most organic compounds contain carbon and hydrogen, but they may also include any number of other elements  </p>

                        </div>
                    </div>

                    <div className="card ms-3 me-3 bg-dark " style={{ width: "18rem" }}>
                        <img className="card-img-top" src="https://edurev.gumlet.io/AllImages/original/ApplicationImages/CourseImages/17c84b44-02b1-4568-803b-11f181af9d02_CI.png" alt="Card image cap" />
                        <div className="card-body ">
                            <h5 className="card-title">InOrganic Chemistry</h5>
                            <p className="card-text">norganic chemistry is the study of the behaviour of compounds along with their properties, their physical and chemical characteristics. The elements of the periodic table except for carbon and hydrogen are in the lists of inorganic compounds. Many of the elements very important like titanium , copper etc.</p>

                        </div>
                    </div>



                </div>


            </div>


            <h1 style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white'
            }} className="mt-5">Available Practicals</h1>

            {loading && <h1 style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white'
            }}>

                <div className="spinner-grow text-success " role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </h1>}

            <div style={{ color: 'whitesmoke' }} className="row d-flex align-items-center justify-content-center mt-4">
                {!loading && experiments.map(experiment => {
                    return <div className='bg-dark mt-2' style={{ width: '914px', borderRadius: '15px', padding: '20px' }} key={experiment._id} onClick={()=>{
                        dispatch(setExpID(experiment._id))
                        navigate(`/experiments/${experiment.title.split(" ").join("")}`)
                    }} >
                        <div style={{
                            fontSize: '25px',
                            textDecoration: 'underline'
                        }}>
                            {experiment.title}
                        </div>
                        <div style={{
                            fontSize: '20px'
                        }}>
                            {experiment.description}

                        </div>
                    </div>
                })}
            </div>
        </>
    )
}

export default MainPage
