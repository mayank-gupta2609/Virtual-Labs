import React from 'react'

function Simulation() {
  return (
    <div>
      
    </div>
  )
}

export default Simulation
