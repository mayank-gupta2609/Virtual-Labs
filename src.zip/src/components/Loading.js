import React from 'react' 
function Loading() {
  return (
    <div style={{
        height:'100vh',
        width:'100vw',
        backgroundColor:'black',
        color:'white',
        display:'flex', 
        justifyContent: 'center',
    }}>
        <div> 
        
       <img src="https://wallpapers.com/images/hd/krishna-phone-peacock-feather-j6kj0bal8knijim6.jpg" alt="" height="500px" />
       <p>|| श्री कृष्ण गोविन्द हरे मुरारी,
हे नाथ नारायण वासुदेवा ॥</p>
        </div>
    </div>
  )
}

export default Loading
