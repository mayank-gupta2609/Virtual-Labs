import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import LoadingBar from 'react-top-loading-bar'
import { useNavigate } from 'react-router-dom'
import { setExpID } from '../redux/features/userSlice';


function ContentPage() {
  const dispatch = useDispatch();
  const { experimentId, section } = useSelector((state) => state.user)
  const navigate = useNavigate()
  // console.log(section);
  const [experiments, setExperiments] = useState()
  const [progress, setProgress] = useState(0)
  const [loading, setLoading] = useState(true)
  const [color, setColor] = useState("red")

  const getExperiments = async () => {
    setProgress(0)
    setColor("orange")
    setLoading(true)
    let response = await fetch(`http://localhost:5000/api/experiments/getSection/${section}`, {
      method: "GET"
    });
    setProgress(50)
    setColor("aqua")
    let data = await response.json();
    console.log(data);
    setExperiments(data)
    setColor("pink")
    setProgress(70)
    setLoading(false)
    setProgress(100)
    setColor("red")
  }


  useEffect(() => {
    getExperiments()
  }, [section])

  return (
    <>
      <LoadingBar
        color={color}
        progress={progress}
        onLoaderFinished={() => setProgress(0)}
      />

      <div style={{
        paddingTop: '100px'
      }}>
        <h1 style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white'
        }}>
          {section}
        </h1>

        {loading && <h1 style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white'
        }}>
           
        <div className="spinner-grow text-success " role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
        </h1>}

        <div style={{ color: 'whitesmoke' }} className="row d-flex align-items-center justify-content-center mt-2">
          {!loading && experiments.map(experiment => {
            return <div className='bg-dark mt-2' style={{ width: '914px', borderRadius: '15px', padding:'20px' }} key={experiment._id} onClick={()=>{
                        dispatch(setExpID(experiment._id))
                        navigate(`/experiments/${experiment.title.split(" ").join("")}`)
                    }}  >
              <div style={{
                fontSize: '25px',
                textDecoration: 'underline'
              }}>
                {experiment.title}
              </div>
              <div style={{
                fontSize: '20px'
              }}>
                {experiment.description}

              </div>
            </div>
          })}
        </div>
      </div>
    </>
  )
}

export default ContentPage
