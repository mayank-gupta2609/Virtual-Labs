import logo from './logo.svg';
import './App.css';
import {doc, setDoc } from "firebase/firestore"
import { auth, db } from './firebase'
import { useAuthState } from "react-firebase-hooks/auth";
import Login from './components/Login';
import Loading from './components/Loading';
import Home from './components/Home';
import EMF from './components/exps/EMF';

function App() {
  const [user, loading] = useAuthState(auth)

  // if(true) return <EMF />
  if(loading) return <Loading />
  if(!user) return <Login />
  return (
    <div >
      <Home />
    </div>
  );
}

export default App;
